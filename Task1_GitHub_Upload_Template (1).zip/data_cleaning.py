import pandas as pd

df = pd.read_csv('customer_personality_analysis_raw.csv')

df = df.drop_duplicates()
df.columns = [c.strip().lower().replace(' ', '_') for c in df.columns]

for col in df.select_dtypes(include='object').columns:
    df[col] = df[col].fillna('Unknown')

df.to_csv('customer_personality_analysis_cleaned.csv', index=False)

print('Cleaning completed')

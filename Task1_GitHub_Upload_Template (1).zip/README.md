# Task 1: Data Cleaning and Preprocessing

Dataset: Customer Personality Analysis

## Objective
Clean and prepare a raw dataset by handling missing values, duplicates, inconsistent formats, and data types.

## Tools Used
- Python
- Pandas

## Changes Performed
- Removed duplicate records
- Handled missing values
- Standardized text formatting
- Renamed column headers
- Converted date columns to a consistent format
- Corrected data types

## Files
- customer_personality_analysis_raw.csv
- customer_personality_analysis_cleaned.csv
- data_cleaning.py
